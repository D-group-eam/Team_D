package com.seol.webpageHaleMaven.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.seol.webpageHaleMaven.entity.Order;
import com.seol.webpageHaleMaven.entity.Order2;

@Repository
public class OrderDaoImpl implements OrderDao {
	
	@Autowired
	SqlSession sqlSession;

	@Override
	public List<Order2> getOrderList() {
		return sqlSession.selectList("mapper.Order.getOrderList");
	}

}
