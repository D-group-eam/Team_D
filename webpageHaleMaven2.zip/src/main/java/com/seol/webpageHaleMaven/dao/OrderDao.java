package com.seol.webpageHaleMaven.dao;

import java.util.List;

import com.seol.webpageHaleMaven.entity.Order;
import com.seol.webpageHaleMaven.entity.Order2;

public interface OrderDao {
	
	List<Order2> getOrderList();

}
