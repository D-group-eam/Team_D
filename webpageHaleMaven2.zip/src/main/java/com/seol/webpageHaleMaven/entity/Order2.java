package com.seol.webpageHaleMaven.entity;

public class Order2 {

	private int mot_id;	
	private int mem_id;	
	private String mem_nickname;
	private String mem_realname;	
	private String mem_email;	
	private String mem_phone;	
	private String mot_memo;	
	private int mot_total_money;	
	private int mot_deposit;	
	private int mot_cash_request;	
	private int mot_cash;	
	private String mot_pay_type;	
	private int mot_status;
	public int getMot_id() {
		return mot_id;
	}
	public void setMot_id(int mot_id) {
		this.mot_id = mot_id;
	}
	public int getMem_id() {
		return mem_id;
	}
	public void setMem_id(int mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_nickname() {
		return mem_nickname;
	}
	public void setMem_nickname(String mem_nickname) {
		this.mem_nickname = mem_nickname;
	}
	public String getMem_realname() {
		return mem_realname;
	}
	public void setMem_realname(String mem_realname) {
		this.mem_realname = mem_realname;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_phone() {
		return mem_phone;
	}
	public void setMem_phone(String mem_phone) {
		this.mem_phone = mem_phone;
	}
	public String getMot_memo() {
		return mot_memo;
	}
	public void setMot_memo(String mot_memo) {
		this.mot_memo = mot_memo;
	}
	public int getMot_total_money() {
		return mot_total_money;
	}
	public void setMot_total_money(int mot_total_money) {
		this.mot_total_money = mot_total_money;
	}
	public int getMot_deposit() {
		return mot_deposit;
	}
	public void setMot_deposit(int mot_deposit) {
		this.mot_deposit = mot_deposit;
	}
	public int getMot_cash_request() {
		return mot_cash_request;
	}
	public void setMot_cash_request(int mot_cash_request) {
		this.mot_cash_request = mot_cash_request;
	}
	public int getMot_cash() {
		return mot_cash;
	}
	public void setMot_cash(int mot_cash) {
		this.mot_cash = mot_cash;
	}
	public String getMot_pay_type() {
		return mot_pay_type;
	}
	public void setMot_pay_type(String mot_pay_type) {
		this.mot_pay_type = mot_pay_type;
	}
	public int getMot_status() {
		return mot_status;
	}
	public void setMot_status(int mot_status) {
		this.mot_status = mot_status;
	}
	
	
}
