package com.seol.webpageHaleMaven.controller;

import java.util.logging.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/item")
public class ItemController {
	
	private Logger logger = Logger.getLogger(getClass().getName());
	
// 상품등록페이지	
	@GetMapping("/itemRegistrationForm")
	public String itemRegistrationForm() {
		
		
		return "/item/item-registration-form";
	}
	

}
