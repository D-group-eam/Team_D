package com.seol.webpageHaleMaven.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;



//SecurityWebApplicationInitializer 은 Spring Security Filters를 등록하기 위한 클래스
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
	

}
