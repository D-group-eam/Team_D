create user 'webpageHale'@'localhost' identified by 'webpageHale';
Grant all privileges on * . * to 'webpageHale'@'localhost';

create database if not exists `webprojecthale`;
use `webprojecthale`;