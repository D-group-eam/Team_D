insert into test_mall_order values (1,1111,'nick','이솝','esop38@gmail.com','010-1234-5678','빠른 배송 주세요',10000,3000,7000,7000,'현금결제',1);
insert into test_mall_order values (2,1111,'nic','남수','abcd@abc.com','010-1114-5678','빠른 배송 주세요',20000,3000,17000,17000,'카드결제',1);
